# Plunge

New functionalities for Data Analysis, leveraging the capabilities of Numpy, Pandas, Matplotlib, Seaborn and Scikit-Learn libraries.